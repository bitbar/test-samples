#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys

from glob import glob
from os.path import abspath, dirname, isdir, join as path_join
from os.path import split as path_split, splitext

from robot import run_cli

CURDIR = abspath(dirname(__file__))
LIBROOT = path_join(CURDIR, 'libs')
RESOURCEROOT = path_join(CURDIR, 'resources')
ESCAPED_CURDIR = CURDIR.replace(' ', '!')
DEFAULT_ARGS = '--escape space:! --variable PROJECTROOT:{root} {source}'.format(
    root=ESCAPED_CURDIR, source=path_join(ESCAPED_CURDIR, 'tests'))

def extend_pythonpath(libroot):
    for dirname in os.listdir(libroot):
        path = path_join(libroot, dirname)
        if isdir(path):
           sys.path.insert(1, path)

def main(cli_args):
    extend_pythonpath(LIBROOT)
    cli_args.extend(DEFAULT_ARGS.split())
    return run_cli(cli_args)

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))